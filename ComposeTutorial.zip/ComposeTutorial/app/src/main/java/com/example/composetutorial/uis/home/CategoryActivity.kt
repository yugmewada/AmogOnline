package com.example.composetutorial.uis.home

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Devices
import androidx.compose.ui.tooling.preview.Preview
import com.example.composetutorial.uis.setData

class CategoryActivity : ComponentActivity() {


    @Preview(showBackground = false, showSystemUi = true, device = Devices.NEXUS_5, name = "MyPreview")
    @Composable
    fun ShowPreview() {
        setData()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            setData()
        }
    }
}