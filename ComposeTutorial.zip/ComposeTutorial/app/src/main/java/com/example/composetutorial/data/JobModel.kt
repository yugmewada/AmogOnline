package com.example.composetutorial.data

data class JobModel(
    val image: Int,
    val title: String,
    val id: String,
    val type: String,
    val date: String
)
