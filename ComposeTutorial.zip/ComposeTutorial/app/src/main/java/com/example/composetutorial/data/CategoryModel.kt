package com.example.composetutorial.data

data class CategoryModel(
    val name: String,
    val image:String
)
